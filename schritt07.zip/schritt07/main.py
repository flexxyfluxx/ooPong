""" Menu:
Hier werden die MainMenu-Methoden definiert.
"""

""" Imports: """
import gamegrid as gg
import ConfigParser as cp
from constants_etc import *
import MainMenu
import ConfigParser as cp # o_o realization
import sys
from Ball import *
from Anzeige import *
from Collisions import *
from DumbSchlaeger import *
from Schlaeger import *
from Spieler import *
from time import sleep
from java.awt.event import KeyListener

# ----- DEFINITIONSBEREICH -----

temp_btn_settings = {
    'obstacles': config.get_obstacle_state(),
    'left_up': config.get_key_left_up(),
    'left_dn': config.get_key_left_dn(),
    'right_up': config.get_key_right_up(),
    'right_dn': config.get_key_right_dn()
}

class menu_key_listener(KeyListener):
    def __init__(self, menu, btn):
        KeyListener.__init__(self)
        self.menu = menu
        self.btn = btn
    
    def keyPressed(self, event):
        print("yeet")
        
    def keyTyped(self, event):
        print("luhgl")
    
    def keyReleased(self, event):
        print("poiga")

def make_listener(menu, btn):
    return menu_key_listener(menu, btn)

def get_key(dict_, val):
    return [key for key, v in dict_.items() if v == val]

def setup_mainmenu(menu):
    menu.jtf_wndw_height.setText(str(config.get_wndw_height()))
    menu.jtf_wndw_width.setText(str(config.get_wndw_width()))
    menu.jtf_ball_speed.setText(str(config.get_ball_speed()))
    
    menu.jbtn_obstacles.setText("An" if config.get_obstacle_state() else "Aus")
    
    menu.jbtn_kbind_left_up.setText(str(get_key(KEY, config.get_key_left_up())[0]))
    menu.jbtn_kbind_left_dn.setText(str(get_key(KEY, config.get_key_left_dn())[0]))
    menu.jbtn_kbind_right_up.setText(str(get_key(KEY, config.get_key_right_up())[0]))
    menu.jbtn_kbind_right_dn.setText(str(get_key(KEY, config.get_key_right_dn())[0]))

def onclick_play(event, menu):
    menu.dispose()
    del sys.modules['MainMenu']
    play_game(False, False)

def onclick_obstacles(event, menu):
    temp_settings['obstacles'] = False if config.get_obstacle_state() \
                            else True
    

def onclick_save_settings(event, menu):
    try:
        config.write_wndw_height(int(menu.jtf_wndw_height.getText()))
    except:
        menu.jtf_wndw_height.setText(str(config.get_wndw_height()))
    
    try:
        config.write_wndw_width(int(menu.jtf_wndw_width.getText()))
    except:
        menu.jtf_wndw_width.setText(str(config.get_wndw_width()))
    
    try:
        config.write_ball_speed(int(menu.jtf_ball_speed.getText()))
    except:
         menu.jtf_ball_speed.setText(str(config.get_ball_speed()))
    
    config.write_obstacles(temp_btn_settings['obstacles'])
    config.write_key_left_up(temp_btn_settings['left_up'])
    config.write_key_left_dn(temp_btn_settings['left_dn'])
    config.write_key_right_up(temp_btn_settings['right_up'])
    config.write_key_right_dn(temp_btn_settings['right_dn'])
    
    config.commit_to_ini()

def onclick_kbind_left_up(event, menu):
    menu.jbtn_kbind_left_up.setText(".....")
    menu.addKeyListener(make_listener(menu, 'left_up'))
    

def onclick_kbind_left_dn(event, menu):
    pass

def onclick_kbind_right_up(event, menu):
    pass

def onclick_kbind_right_dn(event, menu):
    pass

def bind_onclicks(menu):
    menu.jbtn_play.actionPerformed = lambda event: onclick_play(event, menu)
    menu.jbtn_obstacles.actionPerformed = lambda event: onclick_obstacles(event, menu)
    menu.jbtn_save_settings.actionPerformed = lambda event: onclick_save_settings(event, menu)
    menu.jbtn_kbind_left_up.actionPerformed = lambda event: onclick_kbind_left_up(event, menu)
    menu.jbtn_kbind_left_dn.actionPerformed = lambda event: onclick_kbind_left_dn(event, menu)
    menu.jbtn_kbind_right_up.actionPerformed = lambda event: onclick_kbind_right_up(event, menu)
    menu.jbtn_kbind_right_dn.actionPerformed = lambda event: onclick_kbind_right_dn(event, menu)
    
"""
def menu_key_pressed(event, menu, btn):
    temp_btn_settings[btn] = event.getKeyCode()
    if btn == 'left_up':
        menu.jbtn_kbind_left_up.setText(event.getKeyChar())
    elif btn == 'left_dn':
        menu.jbtn_kbind_left_dn.setText(event.getKeyChar())
    elif btn == 'right_up':
        menu.jbtn_kbind_right_up.setText(event.getKeyChar())
    elif btn == 'right_dn':
        menu.jbtn_kbind_right_dn.setText(event.getKeyChar())
    
    menu.removeKeyListener(menu_key_pressed)
    return
#"""


def gg_event_key_press(event):
    """
    Hört auf Keypresses und verarbeitet diese.
    """
    key_codes = gg.getPressedKeyCodes()
    
    if KEY['space'] in key_codes:
        if gg.isRunning():
            gg.doPause()
            gg.setStatusText("Press SPACE to unpause!")
        else:
            gg.doRun()
            gg.setStatusText("Press SPACE to pause!")

def await_keypress(key_code):
    """
    wartet auf den gegebenen Keypress.
    """
    while getKeyCodeWait() != key_code:
        pass

def play_game(show_debug_bar, obstacles = False):
    main_grid = gg.makeGameGrid(config.WINDOW_WIDTH, config.WINDOW_HEIGHT, 1, None, None,
                                        show_debug_bar, keyPressed = gg_event_key_press)
    the_ball = Ball()
    schlaeger_1 = Schlaeger(config.KEY_LEFT_UP, config.KEY_LEFT_DN, the_ball)
    schlaeger_2 = Schlaeger(config.KEY_RIGHT_UP, config.KEY_RIGHT_DN, the_ball)
    if obstacles:
        obstacle_1 = DumbSchlaeger(config.WINDOW_HEIGHT)
        obstacle_2 = DumbSchlaeger(config.WINDOW_HEIGHT)
        gg.addActor(obstacle_1, gg.Location(2 * config.WINDOW_WIDTH // 5, config.WINDOW_HEIGHT // 2), NORTH)
        gg.addActor(obstacle_2, gg.Location(3 * config.WINDOW_WIDTH // 5, config.WINDOW_HEIGHT // 2), SOUTH)
    
    p1_name = inputString("Name Spieler 1: (Weniger als 24 Zeichen!)")
    while len(p1_name) > 24:
        p1_name = inputString("Name Spieler 1: (Weniger als 24 Zeichen!)")
        
    p2_name = inputString("Name Spieler 2: (Weniger als 24 Zeichen!)")
    while len(p2_name) > 24:
        p2_name = inputString("Name Spieler 2: (Weniger als 24 Zeichen!)")

    player_1 = Spieler(p1_name)
    player_2 = Spieler(p2_name)
    
    the_anzeige = Anzeige(main_grid, player_1, player_2)
    
    the_ball.bind_anzeige(the_anzeige)
    the_ball.bind_schlaeger(schlaeger_1, schlaeger_2)

    location_s1 = gg.Location(50, config.WINDOW_HEIGHT // 2)
    location_s2 = gg.Location(config.WINDOW_WIDTH - 50, config.WINDOW_HEIGHT // 2)
    gg.addActor(schlaeger_1, location_s1)
    gg.addActor(schlaeger_2, location_s2)
    
    location_ball = gg.Location(config.WINDOW_WIDTH // 2, config.WINDOW_HEIGHT // 2)
    #"""
    gg.addActor(the_ball, location_ball, choice(START_DIRECTIONS))
    """
    # Specific Angle Debug
    gg.addActor(the_ball, location_ball, 0)
    #"""
    
    ball_collider = Collider()
    
    schlaeger_1.addActorCollisionListener(ball_collider)
    schlaeger_2.addActorCollisionListener(ball_collider)
    
    the_ball.addActorCollisionListener(ball_collider)

    the_ball.addCollisionActor(schlaeger_1)
    the_ball.addCollisionActor(schlaeger_2)
    
    if obstacles:
        obstacle_1.addActorCollisionListener(ball_collider)
        obstacle_2.addActorCollisionListener(ball_collider)
        the_ball.addCollisionActor(obstacle_1)
        the_ball.addCollisionActor(obstacle_2)

    gg.setSimulationPeriod(10)
    
    gg.setTitle("Ponk!")
    gg.addStatusBar(20)
    gg.setStatusText("Press SPACE to start!")
    gg.show()
    the_anzeige.show_scoreboard()
    #"""
    the_anzeige.show_player_names()
    """
    the_anzeige.print_player_names()
    #"""
    
    await_keypress(KEY['space'])
    
    gg.setStatusText("Press SPACE to pause!")  
    gg.doRun()


# ----- ENDE DEFINITIONSBEREICH -----
    
# ----- MAIN -----
if __name__ == "__main__":
    menu = MainMenu()
    setup_mainmenu(menu)
    bind_onclicks(menu)
    
    menu.setVisible(True)